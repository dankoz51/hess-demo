<?php
class Amasty_Shopby_Block_Catalog_Layer_View_Right extends Amasty_Shopby_Block_Catalog_Layer_View
{
    protected $_blockPos = 'right';
}